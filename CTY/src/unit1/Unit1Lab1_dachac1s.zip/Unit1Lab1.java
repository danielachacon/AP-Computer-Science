package unit1;

/**
 * This class displays an image using System.out.println
 * @author neilp
 *
 */
public class Unit1Lab1
{
	/**
	 * Prints out the image using System.out.println
	 * @param args
	 */
	public static void main(String[] args) 
	{
		System.out.println("*********" + "\t" + "***" + "\t" + " *" + "\t" + "   *");
		System.out.println("*\t*" + "      " + "*   *" + "    ***" + "\t  * *");
		System.out.println("*\t*" + "     " + "*     *" + "  *****" + "\t *   *");
		System.out.println("*\t*" + "     " + "*     *" + "    *" + "\t*     *");
		System.out.println("*\t*" + "     " + "*     *" + "    *" + "     *       *");
		System.out.println("*\t*" + "     " + "*     *" + "    *" + "\t*     *");
		System.out.println("*\t*" + "     " + "*     *" + "    *" + "\t *   *");
		System.out.println("*\t*" + "      " + "*   *" + "     *" + "\t  * *");
		System.out.println("*\t*" + "\t" + "***" + "      *"+ "\t" + "   *");
	}

}
