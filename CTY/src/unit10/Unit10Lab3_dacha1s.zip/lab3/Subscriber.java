package unit10.lab3;

public class Subscriber
{
	public void update()
	{
	}
}